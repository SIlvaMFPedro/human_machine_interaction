Este � o projecto de IHC GameMasters - Plataforma de gest�o de compra e venda de jogos.

O nome do projecto � GameMasters mas foi alterado para "ChatBubbles" ao n�vel do c�digo para usar as classes:
-- Message.cs;
-- MessageCollection.cs
-- MessageTemplateSelector.cs
-- StringFormatConverter.cs
-- GridUtils.cs

Elementos do Grupo:
-- Pedro Silva -- pedro.mfsilva@ua.pt --72645
-- Ricardo Pombeiro --  bacalhau@ua.pt -- 71718

Turma: P3
